import React from "react";
import "./UdvalgtTur.scss";
import SelectedTure from "../components/SelectedTure";
const UdvalgtTur = () => {

  return (
    <article id="UdvalgtTur">
      <SelectedTure />
    </article>
  );
};

export default UdvalgtTur;

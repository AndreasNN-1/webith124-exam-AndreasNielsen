import React from 'react'
import "./Error.scss";
const Error = () => {

  // hi :)  how are you
  return (
    <div className='error'>
      <p>Der opstod en fejl...</p>
    </div>
  )
}

export default Error
import "./loader.scss";

const Loader = () => {

  // OMG A LOADER O_O
  return (
    <div className="loader-container">
      <div className="loader" />
    </div>
  );
};

export default Loader;
